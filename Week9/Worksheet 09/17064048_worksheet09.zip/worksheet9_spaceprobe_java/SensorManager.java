package edu.curtin.spaceprobe;

import java.util.*;

public class SensorManager<T extends Collection> implements Resource<T> {
    private T workingSensors;
    private int nSensors;

    public SensorManager(T sensors) {
        workingSensors = new HashSet<>();
        workingSensors.addAll(sensors);
        nSensors = sensors.size();
    }

    @Override
    public void useUp(T amount) {
        for (Sensor sensor : amount) {
            workingSensors.remove(sensor);
        }
    }

    @Override
    public T getRemaining() {
        return workingSensors;
    }

    @Override
    public long getTime(long elapsedTime) {
        double nWorking = (double) workingSensors.size();
        return (long) ((double) elapsedTime / ((double) nSensors - nWorking) * nWorking);
    }
}
