package edu.curtin.spaceprobe;

public class Battery<T> implements Resource<T> {
    private T charge = 100.0;

    public void recharge() {
        charge = 100.0;
    }

    @Override
    public void useUp(T amount) {
        charge -= amount;
    }

    @Override
    public T getRemaining() {
        return charge;
    }

    @Override
    public T getTime(T elapsedTime) {
        return elapsedTime / (100.0 - charge) * charge);
    }
}
