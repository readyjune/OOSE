package edu.curtin.spaceprobe;

public interface Resource
{
    void useUp(Object amount);
    Object getRemaining();
    long getTime(long elapsedTime);
}
